﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;

namespace WebApplication1.Controllers
{
    /// <summary>
    /// Контроль событий.
    /// </summary>
    [ApiController]
    [Route("[controller]")]
    public class Controllers : Controller
    {
        private static List<User> _users = new();
        private static List<MessageInfo> _messages = new();

        /// <summary>
        /// Создание новых пользователей и сообщений.
        /// </summary>
        /// <returns> Информация о пользователях. </returns>
        [HttpPost("create")]
        public IActionResult Create()
        {
            try
            {
                _users = JsonSerializer.Deserialize<List<User>>(System.IO.File.ReadAllText("users.json"));
                _messages = JsonSerializer.Deserialize<List<MessageInfo>>(System.IO.File.ReadAllText("messages.json"));
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            List<string> baseEmail = new();
            foreach(var user in _users)
            {
                baseEmail.Add(user.Email);
            }
            Random rand = new Random();
            int userLength = rand.Next(3, 11);
            string name = "";
            string email = "";
            for (int i = 0; i < userLength; i++)
            {
                while (true)
                {
                    name = "";
                    email = "";
                    name = RandomMetod(rand, name);
                    email = RandomMetod(rand, email);
                    if (!baseEmail.Contains(email))
                    {
                        break;
                    }
                }
                baseEmail.Add(email);
                User user = new(name, email);
                _users.Add(user);
            }
            int messageLength = rand.Next(3, 16);
            string subject = "";
            string sms = "";
            for (int i = 0; i < messageLength; i++)
            {
                subject = "";
                sms = "";
                int received = rand.Next(0, baseEmail.Count);
                int sender = rand.Next(0, baseEmail.Count);
                subject = RandomMetod(rand, subject);
                sms = RandomMetod(rand, sms);
                MessageInfo message = new(subject, sms, baseEmail[sender], baseEmail[received]);
                _messages.Add(message);
            }
            string json = JsonSerializer.Serialize(_users);
            System.IO.File.WriteAllText("users.json", json);
            json = JsonSerializer.Serialize(_messages);
            System.IO.File.WriteAllText("messages.json", json);
            return Ok(_users);
        }

        /// <summary>
        /// Создание рандомной строки.
        /// </summary>
        /// <param name="rand"> Генерация рандома. </param>
        /// <param name="name"> Выходная строка. </param>
        /// <returns></returns>
        private static string RandomMetod(Random rand, string name)
        {
            int nameLength = rand.Next(4, 9);
            for (int j = 0; j < nameLength; j++)
            {
                int nameRandom = rand.Next(0, 26);
                name += (char)('a' + nameRandom);
            }
            return name;
        }

        /// <summary>
        /// Получение информации о пользователе по email.
        /// </summary>
        /// <param name="email"> Емэил. </param>
        /// <returns> Информация о пользователе. </returns>
        [HttpGet("get-user")]
        public IActionResult GetUser([FromQuery] string email)
        {
            var result = _users.Where(x => x.Email == email).ToList();
            return result.Count == 0 ? NotFound() : Ok(result[0]);
        }

        /// <summary>
        /// Получение данных о всех пользователях.
        /// </summary>
        /// <returns> Информация о всех пользователях.</returns>
        [HttpGet("get-all-users")]
        public IActionResult GetAllUsers()
        {
            return Ok(_users);
        }

        /// <summary>
        /// Сообщения по отправителю и получателю.
        /// </summary>
        /// <param name="sender"> Отправитель. </param>
        /// <param name="receiver"> Получатель. </param>
        /// <returns> Сообщения пользователей. </returns>
        [HttpGet("get-message-by-sender-and-receiver")]
        public IActionResult GetMessageBySenderAndReceiver(string sender, string receiver)
        {
            var result = _messages.Where(x => x.SenderId == sender && x.ReceiverId == receiver).ToList();
            return result.Count == 0 ? NotFound() : Ok(result);
        }

        /// <summary>
        /// Сообщения по отправителю.
        /// </summary>
        /// <param name="sender"> Отправитель. </param>
        /// <returns> Сообщения отправленные пользователем. </returns>
        [HttpGet("get-message-by-sender")]
        public IActionResult GetMessageBySender(string sender)
        {
            var result = _messages.Where(x => x.SenderId == sender).ToList();
            return result.Count == 0 ? NotFound() : Ok(result);
        }

        /// <summary>
        /// Сообщения по получателю.
        /// </summary>
        /// <param name="receiver"> Получатель. </param>
        /// <returns> Сообщения этому пользователю. </returns>
        [HttpGet("get-message-by-receiver")]
        public IActionResult GetMessageByReceiver(string receiver)
        {
            var result = _messages.Where(x => x.ReceiverId == receiver).ToList();
            return result.Count == 0 ? NotFound() : Ok(result);
        }
    }
}