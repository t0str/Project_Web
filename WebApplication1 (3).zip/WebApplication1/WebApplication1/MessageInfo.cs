﻿namespace WebApplication1
{
    /// <summary>
    /// Класс сообщений.
    /// </summary>
    public class MessageInfo
    {
        /// <summary>
        /// Тема.
        /// </summary>
        public string Subject { get; set; }
        /// <summary>
        /// Текст сообщения.
        /// </summary>
        public string Message { get; set; }
        /// <summary>
        /// Отправитель.
        /// </summary>
        public string SenderId { get; set; }
        /// <summary>
        /// Получатель.
        /// </summary>
        public string ReceiverId { get; set; }

        /// <summary>
        /// Конструктор сообщений.
        /// </summary>
        /// <param name="subject"> Тема сообщения. </param>
        /// <param name="message"> Текст сообщения. </param>
        /// <param name="senderId"> Отправитель. </param>
        /// <param name="receiverId"> Получатель. </param>
        public MessageInfo(string subject, string message, string senderId, string receiverId)
        {
            Subject = subject;
            Message = message;
            SenderId = senderId;
            ReceiverId = receiverId;
        }
    }
}