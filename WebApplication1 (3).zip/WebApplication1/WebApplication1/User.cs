﻿namespace WebApplication1
{
    /// <summary>
    /// Класс пользователей.
    /// </summary>
    public class User
    {
        /// <summary>
        /// Имя пользователя.
        /// </summary>
        public string UserName { get; set; }
        /// <summary>
        ///  Емэил пользователя.
        /// </summary>
        public string Email { get; set; }

        /// <summary>
        /// Конструктор пользователя.
        /// </summary>
        /// <param name="userName"> Имя пользователя. </param>
        /// <param name="email"> Емэил пользователя. </param>
        public User(string userName, string email)
        {
            UserName = userName;
            Email = email;
        }
    }
}